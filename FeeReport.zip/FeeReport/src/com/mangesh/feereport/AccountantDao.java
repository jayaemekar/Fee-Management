package com.mangesh.feereport;

import java.util.ArrayList;
import java.util.List;

/**
 * Object class for Accountant
 * 
 * @author MangeshEmekar
 *
 */
public class AccountantDao {

	public static List<Accountant> accountantList = new ArrayList<>();
	public static int accountantId = 0;

	public static boolean validate(String name, String password) {

		for (Accountant accountant : accountantList) {

			if (name.equalsIgnoreCase(accountant.getName()) && password.equalsIgnoreCase(accountant.getPassword())) {
				return true;
			}
		}
		return false;
	}

	public static boolean save(Accountant accountant) {

		if (accountantList.size() == 0) {
			Accountant accountant1 = new Accountant(accountantId, "admin", "admin", "admin@gmail.com", "123456789");
			accountantId++;
			Accountant accountant2 = new Accountant(accountantId, "admin1", "admin1", "admin1@gmail.com",
					"91565767687");
			accountantId++;
			Accountant accountant3 = new Accountant(accountantId, "test", "test", "test@gmail.com", "876456789");
			accountantId++;
			Accountant accountant4 = new Accountant(accountantId, "test1", "test1", "test1@gmail.com", "983456789");
			accountantId++;
			Accountant accountant5 = new Accountant(accountantId, "test2", "test2", "test2@gmail.com", "953456789");
			accountantId++;

			accountantList.add(accountant5);
			accountantList.add(accountant4);
			accountantList.add(accountant3);
			accountantList.add(accountant2);
			accountantList.add(accountant1);
			if (accountant != null) {
				accountant.setId(accountantId++);
				accountantList.add(accountant);
			}
		} else {
			accountant.setId(accountantId++);
			accountantList.add(accountant);
		}

		return true;
	}

	public static List<Accountant> view() {

		if (accountantList.size() == 0) {
			Accountant accountant1 = new Accountant(accountantId, "admin", "admin", "admin@gmail.com", "123456789");
			accountantId++;
			Accountant accountant2 = new Accountant(accountantId, "admin1", "admin1", "admin1@gmail.com",
					"91565767687");
			accountantId++;
			Accountant accountant3 = new Accountant(accountantId, "test", "test", "test@gmail.com", "876456789");
			accountantId++;
			Accountant accountant4 = new Accountant(accountantId, "test1", "test1", "test1@gmail.com", "983456789");
			accountantId++;
			Accountant accountant5 = new Accountant(accountantId, "test2", "test2", "test2@gmail.com", "953456789");
			accountantId++;

			accountantList.add(accountant5);
			accountantList.add(accountant4);
			accountantList.add(accountant3);
			accountantList.add(accountant2);
			accountantList.add(accountant1);
		}
		return accountantList;
	}
}
