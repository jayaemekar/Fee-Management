package com.mangesh.feereport;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StudentDao {

	public static Map<Integer, Student> studentMap = new HashMap<>();

	public static int rollnumber = 0;

	public static int save(Student student) {

		if (student != null) {
			student.setRollno(++rollnumber);
			studentMap.put(rollnumber, student);
			return 0;
		} else {
			return 1;
		}

	}

	public static int update(Student student) {

		if (studentMap.get(student.getRollno()) != null) {
			studentMap.put(student.getRollno(), student);
			return 0;
		}
		return 1;

	}

	public static List<Student> view() {

		List<Student> list = new ArrayList<>();

		for (int student : studentMap.keySet()) {

			list.add(studentMap.get(student));
		}
		return list;
	}

	public static Student getStudentByRollno(int rollno) {
		return studentMap.get(rollno);

	}

	public static List<Student> due() {
		List<Student> studentList = view();

		List<Student> dueStudentList = new ArrayList<>();

		for (Student student : studentList) {
			if (student.getDue() > 0) {
				dueStudentList.add(student);
			}
		}
		return dueStudentList;
	}

	public static Map<Integer, Student> getStudentMap() {
		if (studentMap.size() == 0) {

			rollnumber++;
			studentMap.put(rollnumber, new Student(rollnumber, "Jayarani", "jayarani@gmail.com", "Mechanical", 50000,
					30000, 20000, "3025 Parmer Ln", "Nanded", "Manarashtra", "India", "9561789834"));
			rollnumber++;
			studentMap.put(rollnumber, new Student(rollnumber, "Ashwini", "ashwini@gmail.com", "Electronics", 50000,
					30000, 20000, "1206 Fall Ln", "Pune", "Manarashtra", "India", "9111789834"));
			rollnumber++;
			studentMap.put(rollnumber, new Student(rollnumber, "Mangesh", "mangesh@gmail.com", "ComputerScience", 50000,
					50000, 0, "5400 West Apartments", "Mumbai", "Manarashtra", "India", "9961789834"));
			rollnumber++;
			studentMap.put(rollnumber, new Student(rollnumber, "Yogesh", "yogesh@gmail.com", "Civil", 50000, 30000,
					20000, "5400 West Apartments", "Nashik", "Manarashtra", "India", "9961789834"));

		}
		return studentMap;
	}
}
