module FeeReport {
	requires java.desktop;
}